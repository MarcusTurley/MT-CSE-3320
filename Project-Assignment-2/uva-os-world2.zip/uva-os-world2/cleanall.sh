pushd .
cd kernel/
make clean
popd
